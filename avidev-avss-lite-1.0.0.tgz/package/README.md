Dokumentasi dan implementasi KEAMANAN AVSS LITE,sistem ini di buat untuk menjadi pondasi semua aplikasi AviDev berskala kecil seperti profil company ,Landing Page dan dashboard penjualan yang setidaknya membutuhkan login dan validasi

Saat ini AviDev memiliki setidaknya 3 package AVSS(AVIDEV SISTEM SECURITY)
- AVSS LITE → SISTEM KEAMANAN YANG SETIDAKNA MEMBUTUHKAN AUTHENTICATION  DAN VALIDASI INPUT

- AVSS STANDAR → SISTEM KEAMANAN YANG BERSKALA SEDANG YANG MEMBUTUHKAN LOGIN , VALIDASI SERTA TRANSAKSI ONLINE /PAYMENT GATEWAY DAN INTEGRASI KEAMANAN YANG LEBIH LENGKAP

• AVSS ENTERPRISE → SISTEM KEAMANAN   TINGKAT TINGGI YANG DIRANCANG UNTUK APLIKASI SKALA BESAR DENGAN KEBUTUHAN KEAMANAN LANJUTAN, MONITORING, AUDIT, SKALABILITAS, DAN PERLINDUNGAN MAKSIMAL.

Begitupun juga setiap aplikasi memakai AVSS sesuai dengan bobot aplikasi atau website nya nya 
